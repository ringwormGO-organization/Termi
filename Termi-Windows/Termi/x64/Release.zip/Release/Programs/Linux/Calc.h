int Calc();

double sumOfTwoNumbers(double x, double y)
{
    return (x + y);
}

double subOfTwoNumbers(double x, double y)
{
    return (x - y);
}

double mulOfTwoNumbers(double x, double y)
{
    return (x * y);
}

double devOfTwoNumbers(double x, double y)
{
    return (x / y);
}

double opsgTrijustr(double x, double y, double z)
{
    return(x + y + z);
}

double opsgDvijustr(double x, double y)
{
    return(x + x + y + y);
}

double opsgKvdjustr(double x, int sqe)
{
    return(x*sqe);
}

double povrsDvijustr(double x, double y)
{
    return(x*y);
}

double povrsKvdjustr(double x)
{
    return(x*x);
}
