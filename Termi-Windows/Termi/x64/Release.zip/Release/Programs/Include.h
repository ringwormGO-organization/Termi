#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <ctime>

#define MAX 500
#define MAX_FILE 250

#include "Linux/Calc.h"