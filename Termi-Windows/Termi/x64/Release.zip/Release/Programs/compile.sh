g++ -o bin/calc Linux/Calculator.cpp
g++ -o bin/filesys Linux/Filesystem.cpp
g++ -o bin/geocalc Linux/GeoCalculator.cpp
g++ -o bin/Help Linux/help.cpp